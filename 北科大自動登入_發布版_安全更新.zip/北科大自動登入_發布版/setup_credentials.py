import os
from cryptography.fernet import Fernet
from dotenv import set_key, unset_key
import getpass
from pathlib import Path

env_path = Path(__file__).parent / ".env"
key_path = Path(__file__).parent / "secret.key"

def main():
    print("===================================================")
    print("         北科大自動登入系統 - 憑證設定")
    print("===================================================")
    print("請輸入您的學號與密碼 (密碼將會加密儲存)：")
    username = input("請輸入學號: ")
    password = getpass.getpass("請輸入密碼 (輸入時不會顯示字元): ")

    if not key_path.exists():
        key = Fernet.generate_key()
        key_path.write_bytes(key)
    else:
        key = key_path.read_bytes()

    f = Fernet(key)
    encrypted_pw = f.encrypt(password.encode()).decode()

    env_path.touch(exist_ok=True)
    
    unset_key(str(env_path), "NTUT_PASSWORD")
    set_key(str(env_path), "NTUT_USERNAME", username)
    set_key(str(env_path), "NTUT_PASSWORD_ENC", encrypted_pw)
    print("\n憑證已安全加密並儲存！")
    print("===================================================")

if __name__ == "__main__":
    main()
